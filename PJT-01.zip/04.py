with open('data/fruits.txt', 'r', encoding = 'UTF8') as f:
    data2 = []
    data = f.readlines()
    for i in data:
        if i not in data2:
            data2.append(i.rstrip()+' '+str(data.count(i)))
            data2.append('\n')

with open('04.txt', 'w', encoding = 'UTF8') as f2:
    f2.writelines(data2)