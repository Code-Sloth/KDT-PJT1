with open('data/fruits.txt', 'r', encoding = 'UTF8') as f:
    data = f.readlines()
    print(len(data))

with open('02.txt', 'w', encoding = 'UTF8') as f2:
    f2.write(str(len(data)))
    