with open('data/fruits.txt', 'r', encoding = 'UTF8') as f:
    berry = []
    data = f.readlines()
    for i in data:
        if i.endswith('berry\n'):
            if i not in berry:
                berry.append(i)
            
with open('03.txt', 'w', encoding = 'UTF8') as f2:
    f2.write(f'{str(len(berry))}\n')
    f2.writelines(berry)

    