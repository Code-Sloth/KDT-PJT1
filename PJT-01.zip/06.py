import json
from pprint import pprint
# 아래 코드 수정 금지
movies_json = open("data/movies.json", encoding="UTF8")
movies_list = json.load(movies_json)

# 이하 문제 해결을 위한 코드 작성

li = []
data = []

for j in range(6):
    data.append(input())


for k in movies_list:
    di = {} 
    for i in data:
        di[i] = k[i]
    li.append(di)
        
pprint(li)
